
public interface AbGui{
    public void showStatus(String s);

}
