/**
 * This is a dummy class that is used to synchronize the running of alma.
 * We should be able to get rid of this.
 * @author K. Purang
 * @version October 2000
 */


class RunParms{
    public int delay;
    public boolean run;

    public RunParms(){
	delay = 0;
	run = false;
    }

}
